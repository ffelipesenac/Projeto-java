
package view;

import models.Cliente;
import models.Funcionario;
import models.Servico;


public class NewMain {

    
    public static void main(String[] args) {
        //criandouma instancia de um projeto
        Servico s = new Servico();
        Servico s2 = new Servico();
        Cliente c = new Cliente();
        Cliente c2 = new Cliente();
        
        
        
        
        
        //entrada
        s.setId(1);
        s.setDescricao("Teste");
        s.setValor(100);
        
        s2.setId(2);
        s2.setDescricao("Flamengo");
        s2.setValor(1000);
        
        c.setId(1);
        c.setNome("Teste");
        c.setTelefone("11118888");
        
        c2.setId(2);
        c2.setNome("Victor");
        c2.setTelefone("99998888");
        
       
        
        
        
        
        
        //saída
        linha();
        System.out.println("Serviço 1");
        System.out.println("Id: " + s.getId());
        System.out.println("Descrição: " + s.getDescricao());
        System.out.println("Valor: R$ " + s.getValor());
        linha();
        System.out.println("Serviço 2");
        System.out.println("Id" + s2.getId());
        System.out.println("Descrição: " + s2.getDescricao());
        System.out.println("Valor " + s2.getValor());
        linha();
        linha();
        System.out.println("Cliente 1");
        System.out.println("Id" + c.getId());
        System.out.println("Nome: " + c.getNome());
        System.out.println("Telefone: " + c.getTelefone());
        linha();
        linha();
        System.out.println("Cliente 2");
        System.out.println("Id" + c.getId());
        System.out.println("Nome: " + c2.getNome());
        System.out.println("Telefone: " + c2.getTelefone());
        linha();
        
    }
    public static void linha(){
        System.out.println("***************************");
    }
}
