/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import conexao.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import models.Cliente;

/**
 *
 * @author 42labinfo
 */
public class ClienteDao {
     public void create(){
        
    }
    public void create(Cliente c) throws SQLException{
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement sql = null;
        
     try{
        sql = con.prepareStatement("insert into cliente(nome,telefone,email,endereco,rg,cpf,cep)values (?,?,?,?,?,?,?)");
        sql.setString(1, c.getNome());
        sql.setString(2, c.getTelefone());
        sql.setString(3, c.getEmail());
        sql.setString(4, c.getEndereco());
        sql.setString(5, c.getRg());
        sql.setString(6, c.getCpf());
        sql.setString(7, c.getCep());
        
        
        sql.executeUpdate();
        
        JOptionPane.showMessageDialog(null, "Cadastrado com sucesso!");
    }catch(SQLException ex) {
        JOptionPane.showMessageDialog(null, "Erro ao Cadastrar: " + ex);
    }finally {
            ConnectionFactory.closeConnection(con, sql);
       }
    }

    public List<Cliente> read() throws SQLException{
        
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement sql = null;
        ResultSet rs = null;
        
        List<Cliente> clientes = new ArrayList<>();
        
        try{
            sql = con.prepareStatement("select * from cliente");
            rs = sql.executeQuery();
            
            while (rs.next()){
               Cliente cliente = new Cliente();
               
               cliente.setId(rs.getInt("id"));
               cliente.setNome(rs.getString("nome"));
               cliente.setTelefone(rs.getString("telefone"));
               cliente.setEmail(rs.getString("email"));
               cliente.setEndereco(rs.getString("endereco"));
               cliente.setRg(rs.getString("rg"));
               cliente.setCpf(rs.getString("cpf"));
               cliente.setCep(rs.getString("cep"));
               
               clientes.add(cliente);
               
            }
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Erro ao acessar o banco de dados: " + ex);
        }finally{
            ConnectionFactory.closeConnection(con, sql, rs);
        }
        
       return clientes; 
    }
    
    
    public void update(Cliente c) throws SQLException{
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement sql = null;
        
        try{
            sql = con.prepareCall("update cliente set nome = ?, telefone = ?, email = ?, endereco = ?, rg = ?, cpf = ?, cep = ?  where id = ?");  
            sql.setString(1,c.getNome());
            sql.setString(2, c.getTelefone());
            sql.setString(3, c.getEmail());
            sql.setString(4, c.getEndereco());
            sql.setString(5,c.getRg());
            sql.setString(6, c.getCpf());
            sql.setString(7, c.getCep());
            
            
            sql.setInt(8, c.getId());
            
            sql.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Dados Atualizados com Sucesso!");
            
        }catch(SQLException ex){
                 JOptionPane.showMessageDialog(null, "Erro ao Atualizar!" + ex);
        
    }finally{
            ConnectionFactory.closeConnection(con, sql);
            }
    }
    
    public void delete(Cliente s) throws SQLException{
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement sql = null;
        
        try{
            sql = con.prepareStatement("delete from cliente where id = ?");
            sql.setInt(1,s.getId());
            
            sql.executeUpdate();
            JOptionPane.showMessageDialog(null, "Excluido com Sucesso!");
            
        }catch(SQLException ex){
        JOptionPane.showMessageDialog(null, "Erro ao Excluir:" + ex);
    }finally{
            ConnectionFactory.closeConnection(con, sql);
            }
        
    }
    
    public List<Cliente> readBusca(String busca) throws SQLException{
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement sql = null;
        ResultSet rs = null;
        
        List<Cliente> clientes = new ArrayList<>();
        
        try{
            sql = con.prepareCall("select * from cliente where id like? or cpf like? or nome like?");
            sql.setString(1, busca);
            sql.setString(2,busca);
            sql.setString(3,"%"+ busca +"%");
            rs = sql.executeQuery();
            
            while (rs.next()){
               Cliente cliente = new Cliente();
               
               cliente.setId(rs.getInt("id"));
               cliente.setNome(rs.getString("nome"));
               cliente.setTelefone(rs.getString("telefone"));
               cliente.setEmail(rs.getString("email"));
               cliente.setEndereco(rs.getString("endereco"));
               cliente.setRg(rs.getString("rg"));
               cliente.setCpf(rs.getString("cpf"));
               cliente.setCep(rs.getString("cep"));
               
               clientes.add(cliente);
               
            }
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Erro ao acessar o banco de dados: " + ex);
        }finally{
            ConnectionFactory.closeConnection(con, sql, rs);
        }
        
       return clientes; 
    }
}
