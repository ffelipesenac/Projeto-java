
package dao;


import models.Produto;
import conexao.ConnectionFactory;


import java.util.List;
import java.util.ArrayList;
import javax.swing.JOptionPane;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class ProdutoDao {
    public void create(){
        
    }
    public void create(Produto p) throws SQLException{
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement sql = null;
        
     try{
        sql = con.prepareStatement("insert into produto(nomep,preco)values (?,?)");
        sql.setString(1, p.getNomep());
        sql.setFloat(2, p.getPreco());
        
        sql.executeUpdate();
        
        JOptionPane.showMessageDialog(null, "Cadastrado com sucesso!");
    }catch(SQLException ex) {
        JOptionPane.showMessageDialog(null, "Erro ao Cadastrar: " + ex);
    }finally {
            ConnectionFactory.closeConnection(con, sql);
       }
    }

    public List<Produto> read() throws SQLException{
        
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement sql = null;
        ResultSet rs = null;
        
        List<Produto> produtos = new ArrayList<>();
        
        try{
            sql = con.prepareCall("select * from produto");
            rs = sql.executeQuery();
            
            while (rs.next()){
               Produto produto = new Produto();
               
               produto.setId(rs.getInt("id"));
               produto.setNomep(rs.getString("nomep"));
               produto.setPreco(rs.getFloat("preco"));
               
               produtos.add(produto);
               
            }
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Erro ao acessar o banco de dados: " + ex);
        }finally{
            ConnectionFactory.closeConnection(con, sql, rs);
        }
        
       return  produtos; 
    }
    
    
    public void update(Produto p) throws SQLException{
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement sql = null;
        
        try{
            sql = con.prepareCall("update produto set nomep = ?, preco = ? where id = ?");  
            sql.setString(1, p.getNomep());
            sql.setFloat(2, p.getPreco());
            sql.setInt(3, p.getId());
            
            sql.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Dados Atualizados com Sucesso!");
            
        }catch(SQLException ex){
                 JOptionPane.showMessageDialog(null, "Erro ao Atualizar!" + ex);
        
    }finally{
            ConnectionFactory.closeConnection(con, sql);
            }
    }
    
    public void delete(Produto p) throws SQLException{
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement sql = null;
        
        try{
            sql = con.prepareStatement("delete from produto where id = ?");
            sql.setInt(1,p.getId());
            
            sql.executeUpdate();
            JOptionPane.showMessageDialog(null, "Excluido com Sucesso!");
            
        }catch(SQLException ex){
        JOptionPane.showMessageDialog(null, "Erro ao Excluir:" + ex);
    }finally{
            ConnectionFactory.closeConnection(con, sql);
            }
        
    }
    
    public List<Produto> readBusca(String busca) throws SQLException{
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement sql = null;
        ResultSet rs = null;
        
        List<Produto> produtos = new ArrayList<>();
        
        try{
            sql = con.prepareCall("select * from produto where nomep like ? or preco like ?");
            sql.setString(1,"%"+ busca +"%");
            sql.setString(2, "%" + busca + "%");
            rs = sql.executeQuery();
            
            while (rs.next()){
               Produto produto = new Produto();
               
               produto.setId(rs.getInt("id"));
               produto.setNomep(rs.getString("nomep"));
               produto.setPreco(rs.getFloat("preco"));
               
               produtos.add(produto);
               
            }
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Erro ao acessar o banco de dados: " + ex);
        }finally{
            ConnectionFactory.closeConnection(con, sql, rs);
        }
        
       return produtos; 
    }
    
}