/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import conexao.ConnectionFactory;
import models.Usuario;

import java.util.List;
import java.util.ArrayList;
import javax.swing.JOptionPane;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import view.TelaLogin;
import view.TelaPrincipal;




public class UsuarioDao {
    
    private final TelaLogin telaLogin;
    
    public UsuarioDao(TelaLogin telaLogin) {
        this.telaLogin = telaLogin;
    }
    
   public void create(Usuario u) throws SQLException{
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement sql = null;
        
     try{
        sql = con.prepareStatement("insert into usuario(login,senha)values (?,?)");
        sql.setString(1, u.getLogin());
        sql.setString(2, u.getSenha());
        
        sql.executeUpdate();
        
        JOptionPane.showMessageDialog(null, "Cadastrado com sucesso!");
    }catch(SQLException ex) {
        JOptionPane.showMessageDialog(null, "Erro ao Cadastrar: " + ex);
    }finally {
            ConnectionFactory.closeConnection(con, sql);
       }
    }

    public List<Usuario> read() throws SQLException{
        
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement sql = null;
        ResultSet rs = null;
        
        List<Usuario> usuarios = new ArrayList<>();
        
        try{
            sql = con.prepareCall("select * from servico");
            rs = sql.executeQuery();
            
            while (rs.next()){
               Usuario usuario = new Usuario();
               
              
               usuario.setLogin(rs.getString("login"));
               usuario.setSenha(rs.getString("senha"));
               
               usuarios.add(usuario);
               
            }
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Erro ao acessar o banco de dados: " + ex);
        }finally{
            ConnectionFactory.closeConnection(con, sql, rs);
        }
        
       return  usuarios; 
    }
    
    
    public void update(Usuario u) throws SQLException{
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement sql = null;
        
        try{
            sql = con.prepareCall("update servico set senha = ?,where login = ?");  
            sql.setString(1, u.getSenha());
            sql.setString(2, u.getLogin());
           
            
            sql.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Dados Atualizados com Sucesso!");
            
        }catch(SQLException ex){
                 JOptionPane.showMessageDialog(null, "Erro ao Atualizar!" + ex);
        
    }finally{
            ConnectionFactory.closeConnection(con, sql);
            }
    }
    
    public void delete(Usuario u) throws SQLException{
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement sql = null;
        
        try{
            sql = con.prepareStatement("delete from servico where login = ?");
            sql.setString(1,u.getLogin());
            
            sql.executeUpdate();
            JOptionPane.showMessageDialog(null, "Excluido com Sucesso!");
            
        }catch(SQLException ex){
        JOptionPane.showMessageDialog(null, "Erro ao Excluir:" + ex);
    }finally{
            ConnectionFactory.closeConnection(con, sql);
            }
        
    } 
    
    public void loginSistema(String login, String senha) throws SQLException{
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement sql = null;
        ResultSet rs = null;
        int achei = 0;
        
        try {
            sql =con.prepareStatement("select * from usuario");
             rs = sql.executeQuery();
             
            while(rs.next()){
                String user = rs.getString("login");
                String password = rs.getString("senha");
                
                if (login.equals(user) && senha.equals(password)){
                    new TelaPrincipal().setVisible(true);
                    this.telaLogin.dispose();
                    achei = 1;                    
                    break;
                }
                
            }
            
            if (achei == 0) {
                    JOptionPane.showMessageDialog(null, "Usuário ou Senha incorretos!");
            
            }
        }catch(SQLException ex){
        JOptionPane.showMessageDialog(null, "Erro ao Acessar o Banco de Dados: " + ex);
    }finally{
            ConnectionFactory.closeConnection(con, sql);
            }
    }
}
